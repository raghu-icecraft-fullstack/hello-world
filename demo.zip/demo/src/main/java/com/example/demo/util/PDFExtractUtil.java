package com.example.demo.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

public class PDFExtractUtil {

	public static String extractPDFFile() {
		System.out.println("\n");
		System.out.println("PDF Extracted started");
		System.out.println("\n");
		File fileName = new File("D:\\ILineSoft\\brand_validation\\PDFs\\TRUE\\testlogo.pdf");
		StringBuilder sb = new StringBuilder();
		try  {
			PDDocument document = PDDocument.load(fileName);
			document.getClass();

			if (!document.isEncrypted()) {

				PDFTextStripperByArea stripper = new PDFTextStripperByArea();
				stripper.setSortByPosition(true);

				PDFTextStripper tStripper = new PDFTextStripper();

				String pdfFileInText = tStripper.getText(document);
				// System.out.println("Text:" + st);

				// split by whitespace
				String lines[] = pdfFileInText.split("\\r?\\n");
				List<String> pdfLines = new ArrayList<>();
				
				int count = 0;
				for (String line : lines) {
					System.out.println(" Line number : " + (++count));
					System.out.println(line);
					pdfLines.add(line);
					sb.append(line + "\n");
				}
				System.out.println("\n");
				System.out.println("\n");
			}

		}catch(Exception ex) {
			System.out.println("Exception ex : " +ex);
		}
		
		return sb.toString();
	}
}
