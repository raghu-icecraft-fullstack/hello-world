package com.example.demo.controller.service;

import org.springframework.stereotype.Component;

import com.example.demo.util.PDFExtractUtil;

@Component
public class PDFExtractService {

	public void extractService() {
		String extractedData = PDFExtractUtil.extractPDFFile();
		System.out.println("******************Extracted details below*********************" );
		System.out.println("\n");
		System.out.println(extractedData);
		System.out.println("**************************************************************" );
	}

}
