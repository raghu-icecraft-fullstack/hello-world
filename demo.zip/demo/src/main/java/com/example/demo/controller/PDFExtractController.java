package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.controller.service.PDFExtractService;

@RestController
public class PDFExtractController {
	
	@Autowired
	PDFExtractService extractService;
	
	@GetMapping("/pdfextract")
	public ResponseEntity<String> getPDFExtract() {
		System.out.println("\n");
		System.out.println("pdfextract api invoked");
		System.out.println("\n");
		extractService.extractService();
		return new ResponseEntity<String>("Extracted and output displayed in console", HttpStatus.ACCEPTED);
	}
}
