package com.example.poc.pdfextract;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.contentstream.PDFStreamEngine;
import org.apache.pdfbox.contentstream.operator.DrawObject;
import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.contentstream.operator.state.Concatenate;
import org.apache.pdfbox.contentstream.operator.state.Restore;
import org.apache.pdfbox.contentstream.operator.state.Save;
import org.apache.pdfbox.contentstream.operator.state.SetGraphicsStateParameters;
import org.apache.pdfbox.contentstream.operator.state.SetMatrix;
import org.apache.pdfbox.cos.COSBase;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.pdfbox.util.Matrix;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.util.LoadLibs;
import org.apache.pdfbox.io.RandomAccessFile;

//@SpringBootApplication
public class PdfExtractApplication extends PDFStreamEngine {

	/**
     * @throws IOException If there is an error loading text stripper properties.
     */
    public PdfExtractApplication() throws IOException
    {
        // preparing PDFStreamEngine
        addOperator(new Concatenate());
        addOperator(new DrawObject());
        addOperator(new SetGraphicsStateParameters());
        addOperator(new Save());
        addOperator(new Restore());
        addOperator(new SetMatrix());
    }
  
    /**
     * @throws IOException If there is an error parsing the document.
     */
    public static void main( String[] args ) throws IOException
    {
//        PDDocument document = null;
        File fileName = new File("D:\\ILineSoft\\brand_validation\\PDFs\\MSA\\test.pdf");
        
        try (PDDocument document = PDDocument.load(fileName)) {

            document.getClass();

            if (!document.isEncrypted()) {

                PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                stripper.setSortByPosition(true);

                PDFTextStripper tStripper = new PDFTextStripper();

                String pdfFileInText = tStripper.getText(document);
                // System.out.println("Text:" + st);

                // split by whitespace
                String lines[] = pdfFileInText.split("\\r?\\n");
                List<String> pdfLines = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                int count = 0;
                for (String line : lines) {
                	System.out.println(" Line number : " +(++count));
                    System.out.println(line);
                    pdfLines.add(line);
                    sb.append(line + "\n");
                }
                System.out.println("\n");
                System.out.println("\n");
                System.out.println(" ******************Final Output****************** " );
                System.out.println(sb.toString());
                System.out.println(" ************************************ " );
            }

        }
        
        finally
        {
         
        }
    }
  
    /**
     * @param operator The operation to perform.
     * @param operands The list of arguments.
     *
     * @throws IOException If there is an error processing the operation.
     */
    @Override
    protected void processOperator( Operator operator, List<COSBase> operands) throws IOException
    {
        String operation = operator.getName();
        if( "Do".equals(operation) )
        {
            COSName objectName = (COSName) operands.get( 0 );
            // get the PDF object
            PDXObject xobject = getResources().getXObject( objectName );
            // check if the object is an image object
            if( xobject instanceof PDImageXObject)
            {
                PDImageXObject image = (PDImageXObject)xobject;
                BufferedImage bImage = image.getImage();
                Tesseract tesseract = new Tesseract();
                try {
                	File tessDataFolder = LoadLibs.extractTessResources("tessdata");

                    tesseract.setDatapath(tessDataFolder.getAbsolutePath());

                	File outputfile = new File("C:\\Users\\ksudhersanam\\OneDrive - homesite.com\\Documents\\PDF EXTRACT\\output\\image.jpg");
                	ImageIO.write(bImage, "jpg", outputfile);
          
                    // the path of your tess data folder
                    // inside the extracted file
                    String text
                        = tesseract.doOCR(new File("C:\\Users\\ksudhersanam\\OneDrive - homesite.com\\Documents\\PDF EXTRACT\\output\\image.jpg"));
          
                    // path of your image file
                    System.out.print(text);
                }
                catch (TesseractException e) {
                    e.printStackTrace();
                }
                int imageWidth = image.getWidth();
                int imageHeight = image.getHeight();

                System.out.println("\nImage [" + objectName.getName() + "]");
                Matrix ctmNew = getGraphicsState().getCurrentTransformationMatrix();
                float imageXScale = ctmNew.getScalingFactorX();
                float imageYScale = ctmNew.getScalingFactorY();
                 
                // position of image in the pdf in terms of user space units
                System.out.println("position in PDF = " + ctmNew.getTranslateX() + ", " + ctmNew.getTranslateY() + " in user space units");
                // raw size in pixels
                System.out.println("raw image size  width = " + imageWidth + " in pixels");
                System.out.println("raw image size  height = " + imageHeight + " in pixels");
                // displayed size in user space units
                System.out.println("displayed size  = " + imageXScale + ", " + imageYScale + " in user space units");
            }
            else if(xobject instanceof PDFormXObject)
            {
                PDFormXObject form = (PDFormXObject)xobject;
                showForm(form);
            }
        }
        else
        {
            super.processOperator( operator, operands);
        }
    }

}
