package com.example.multimodulelibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiModuleLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiModuleLibraryApplication.class, args);
	}

}
