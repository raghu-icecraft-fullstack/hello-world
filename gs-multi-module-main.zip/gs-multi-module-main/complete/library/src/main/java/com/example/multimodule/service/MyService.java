package com.example.multimodule.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@EnableConfigurationProperties(ServiceProperties.class)
public class MyService {
	

	@Autowired
	Environment env;
	
	private String  configValue1;
	

	private String  configValue2;


	private final ServiceProperties serviceProperties;

	public MyService(ServiceProperties serviceProperties) {
		this.serviceProperties = serviceProperties;
	}

	public String message() {
		System.out.println("***********configValue1*******"+env.getProperty("service.message"));
		System.out.println("***********configValue2*******"+configValue2);
		return this.serviceProperties.getMessage();
	}
}
