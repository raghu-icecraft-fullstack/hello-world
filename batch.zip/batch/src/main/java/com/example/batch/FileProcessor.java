package com.example.batch;

import org.springframework.batch.item.ItemProcessor;

public class FileProcessor implements ItemProcessor<String, String>  {

	@Override
	public String process(String data) throws Exception {
		System.out.println("processing.................");		
		System.out.println("FileProcessor : Processing data : "+data);
		data = data.toUpperCase();
		return data;
	}

}
