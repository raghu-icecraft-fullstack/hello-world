package com.example.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

public class DBWriter implements ItemWriter<String> {

	@Override
	public void write(List<? extends String> list) throws Exception {
		System.out.println("Writing.................");		
		for (String data : list) {
			System.out.println("DBWriter    : Writing data    : " + data);
		}
		System.out.println("DBWriter    : Writing data    : completed");
	}

}
